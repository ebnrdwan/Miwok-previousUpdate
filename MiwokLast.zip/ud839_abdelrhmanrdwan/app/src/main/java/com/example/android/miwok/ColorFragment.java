package com.example.android.miwok;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by Abdulrhman on 18/09/2016.
 */
public class ColorFragment extends Fragment {
    private MediaPlayer colorSound;
    private AudioManager audioManager;
    private AudioManager.OnAudioFocusChangeListener audiolistener = new AudioManager.OnAudioFocusChangeListener() {
        @Override
        public void onAudioFocusChange(int focusChange) {
            if (focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                colorSound.pause();
                if (focusChange == AudioManager.AUDIOFOCUS_GAIN) {
                    colorSound.start();
                }
            } else if (focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) {
                int maxVolume = 50;
                int currVolume = audioManager.getStreamVolume(audioManager.STREAM_MUSIC);
                float log1 = (float) (Math.log(maxVolume - currVolume) / Math.log(maxVolume));
                colorSound.setVolume(1 - log1, 1 - log1);
            } else if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
                releaseMediaPlayer();

            }

        }
    };

    private MediaPlayer.OnCompletionListener complistener = new MediaPlayer.OnCompletionListener() {
        @Override
        public void onCompletion(MediaPlayer mp) {
            releaseMediaPlayer();
        }
    };

    @Override
    public void onPause() {
        super.onPause();
        releaseMediaPlayer();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootview = inflater.inflate(R.layout.activity_colors,container,false);

        audioManager = (AudioManager)getActivity().getSystemService(Context.AUDIO_SERVICE);
        final ArrayList<word> colors = new ArrayList<word>();
        colors.add(new word("red", "weṭeṭṭi", R.drawable.color_red, R.raw.color_red));
        colors.add(new word("mustard yellow", "chiwiiṭә", R.drawable.color_mustard_yellow, R.raw.color_mustard_yellow));
        colors.add(new word("dusty yellow", "ṭopiisә", R.drawable.color_dusty_yellow, R.raw.color_dusty_yellow));
        colors.add(new word("green", "chokokki", R.drawable.color_green, R.raw.color_green));
        colors.add(new word("brown", "ṭakaakki", R.drawable.color_brown, R.raw.color_brown));
        colors.add(new word("gray", "ṭopoppi", R.drawable.color_gray, R.raw.color_gray));
        colors.add(new word("black", "kululli", R.drawable.color_black, R.raw.color_black));
        colors.add(new word("white", "kelelli", R.drawable.color_white, R.raw.color_white));

        // Create an {@link wordAdapter}, whose data source is a list of {@link word}s. The
        // adapter knows how to create list items for each item in the list.
        wordAdapter adapter = new wordAdapter(getActivity(), colors, R.color.category_colors);

        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // word_list.xml layout file.
        ListView listView = (ListView)rootview.findViewById(R.id.colors_list);

        // Make the {@link ListView} use the {@link wordAdapter} we created above, so that the
        // {@link ListView} will display list items for each {@link word} in the list.
        listView.setAdapter(adapter);

        // Set a click listener to play the audio when the list item is clicked on


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                // Get the {@link word} object at the given position the user clicked on
                word wordcolor = colors.get(position);

                int result = audioManager.requestAudioFocus(audiolistener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
                if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                    //PLAY
                    // Create and setup the {@link MediaPlayer} for the audio resource associated
                    // with the current word
                    releaseMediaPlayer();
                    colorSound = MediaPlayer.create(getActivity(), wordcolor.getAudioID());
                    // Start the audio file
                    colorSound.start();
                    colorSound.setOnCompletionListener(complistener);
                }
                if (result == AudioManager.AUDIOFOCUS_REQUEST_FAILED) {
                    Toast.makeText(getActivity(), "try to load again", Toast.LENGTH_SHORT);
                }


            }
        });
        return rootview;
    }



    private void releaseMediaPlayer() {
        // If the media player is not null, then it may be currently playing a sound.
        if (colorSound != null) {
            // Regardless of the current state of the media player, release its resources
            // because we no longer need it.
            colorSound.release();

            // Set the media player back to null. For our code, we've decided that
            // setting the media player to null is an easy way to tell that the media player
            // is not configured to play an audio file at the moment.
            colorSound = null;
            audioManager.abandonAudioFocus(audiolistener);
        }

    }
}
