package com.example.android.miwok;


import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class NumberFragment extends Fragment {
    private MediaPlayer sond;
    //@// STOPSHIP: 05/09/2016 1
    private AudioManager audioManager;

    private MediaPlayer.OnCompletionListener Complistener = new MediaPlayer.OnCompletionListener() {
        @Override
        public void onCompletion(MediaPlayer mp) {
            releaseMediaPlayer();
        }
    };

    // // STOPSHIP: 05/09/2016 4
    // set AUDIO FOCUS change listeners
    private AudioManager.OnAudioFocusChangeListener audiolistener = new AudioManager.OnAudioFocusChangeListener() {
        @Override
        public void onAudioFocusChange(int focusChange) {

            if (focusChange == audioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                sond.stop();
                //PUSE THE PLAY
            } else if (focusChange == audioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) {
                int maxVolume = 50;
                int currVolume = audioManager.getStreamVolume(audioManager.STREAM_MUSIC);
                float log1 = (float) (Math.log(maxVolume - currVolume) / Math.log(maxVolume));
                sond.setVolume(1 - log1, 1 - log1);
            } else if (focusChange == audioManager.AUDIOFOCUS_GAIN) {
                //resume playing
                sond.seekTo(0);
                sond.start();
            } else if (focusChange == audioManager.AUDIOFOCUS_LOSS) {
                releaseMediaPlayer();

            }

        }
    };


    public NumberFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        TextView textView = new TextView(getActivity());
        textView.setText(R.string.hello_blank_fragment);
        View rootView = inflater.inflate(R.layout.activity_numbers, container, false);

        // Create and setup the {@link AudioManager} to request audio focus
        audioManager =(AudioManager)getActivity().getSystemService(Context.AUDIO_SERVICE);

        final ArrayList<word> names = new ArrayList<word>();

        names.add(new word("one", "lutti", R.drawable.number_one, R.raw.number_one));
        names.add(new word("two", "otiiko", R.drawable.number_two, R.raw.number_two));
        names.add(new word("three", "tolookosu", R.drawable.number_three, R.raw.number_three));
        names.add(new word("four", "oyyisa", R.drawable.number_four, R.raw.number_four));
        names.add(new word("five", "massokka", R.drawable.number_five, R.raw.number_five));
        names.add(new word("six", "temmokka", R.drawable.number_six, R.raw.number_six));
        names.add(new word("seven", "kenekaku", R.drawable.number_seven, R.raw.number_seven));
        names.add(new word("eight", "kawinta", R.drawable.number_eight, R.raw.number_eight));
        names.add(new word("nine", "wo’e", R.drawable.number_nine, R.raw.number_nine));
        names.add(new word("ten", "na’aacha", R.drawable.number_ten, R.raw.number_ten));
        names.add(new word("one", "lutti", R.drawable.number_one, R.raw.number_one));
        names.add(new word("two", "otiiko", R.drawable.number_two, R.raw.number_two));
        names.add(new word("three", "tolookosu", R.drawable.number_three, R.raw.number_three));
        names.add(new word("four", "oyyisa", R.drawable.number_four, R.raw.number_four));
        names.add(new word("five", "massokka", R.drawable.number_five, R.raw.number_five));
        names.add(new word("six", "temmokka", R.drawable.number_six, R.raw.number_six));
        names.add(new word("seven", "kenekaku", R.drawable.number_seven, R.raw.number_seven));
        names.add(new word("eight", "kawinta", R.drawable.number_eight, R.raw.number_eight));
        names.add(new word("nine", "wo’e", R.drawable.number_nine, R.raw.number_nine));
        names.add(new word("ten", "na’aacha", R.drawable.number_ten, R.raw.number_ten));
        names.add(new word("one", "lutti", R.drawable.number_one, R.raw.number_one));
        names.add(new word("two", "otiiko", R.drawable.number_two, R.raw.number_two));
        names.add(new word("three", "tolookosu", R.drawable.number_three, R.raw.number_three));
        names.add(new word("four", "oyyisa", R.drawable.number_four, R.raw.number_four));
        names.add(new word("five", "massokka", R.drawable.number_five, R.raw.number_five));
        names.add(new word("six", "temmokka", R.drawable.number_six, R.raw.number_six));
        names.add(new word("seven", "kenekaku", R.drawable.number_seven, R.raw.number_seven));
        names.add(new word("eight", "kawinta", R.drawable.number_eight, R.raw.number_eight));
        names.add(new word("nine", "wo’e", R.drawable.number_nine, R.raw.number_nine));
        names.add(new word("ten", "na’aacha", R.drawable.number_ten, R.raw.number_ten));


        //  ArrayAdapter<word> itemsAdapter = new ArrayAdapter<word>(this, names);
        wordAdapter itemsAdapter = new wordAdapter(getActivity(), names, R.color.category_numbers);


        final ListView listView = (ListView) rootView.findViewById(R.id.gridview);
        listView.setAdapter(itemsAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {


            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                releaseMediaPlayer();
                word wordsound = names.get(position);
                //create audio focus
                // // STOPSHIP: 05/09/2016 3
                // we have now request for AUDIO FOCUS every time we click on an item
                // it may require multible clicks for gaining focus
                int result = audioManager.requestAudioFocus(audiolistener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
                if (result == audioManager.AUDIOFOCUS_REQUEST_GRANTED) {

                    sond = MediaPlayer.create(getActivity(), wordsound.getAudioID());
                    sond.start();
                    sond.setOnCompletionListener(Complistener);

                }

            }
        });

        return rootView;
    }
    private void releaseMediaPlayer() {
        // If the media player is not null, then it may be currently playing a sound.
        if (sond != null) {
            // Regardless of the current state of the media player, release its resources
            // because we no longer need it.
            sond.release();

            // Set the media player back to null. For our code, we've decided that
            // setting the media player to null is an easy way to tell that the media player
            // is not configured to play an audio file at the moment.
            sond = null;
            audioManager.abandonAudioFocus(audiolistener);
        }
    }

}
