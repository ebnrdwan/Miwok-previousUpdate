package com.example.android.miwok;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

/**
 * Created by Abdulrhman on 18/09/2016.
 */
public class playonaFragment extends Fragment {


    private MediaPlayer rise;
    private AudioManager audioManager;
    private MediaPlayer.OnCompletionListener complistener = new MediaPlayer.OnCompletionListener() {
        @Override
        public void onCompletion(MediaPlayer mp) {
            releaseMediaPlayer();
        }
    };

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootview = inflater.inflate(R.layout.activity_playona,container,false);

        Button riseplay = (Button)rootview.findViewById(R.id.play);
        Button risepuse = (Button)rootview.findViewById(R.id.puse);
        Button risereset = (Button) rootview.findViewById(R.id.reset);
        releaseMediaPlayer();
        if (riseplay!= null&& risepuse!= null&& risereset!=null){  riseplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (rise == null) {
                    rise = MediaPlayer.create(getActivity(), R.raw.rise);
                    rise.start();
                    rise.setOnCompletionListener(complistener);
                } else
                if (rise.isPlaying()) {
                } else {
                    rise.start();
                }

            }
        });
            risepuse.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (rise == null) {
                        Toast.makeText(getActivity(), "no file to puse", Toast.LENGTH_SHORT).show();
                    } else if (rise.isPlaying()) {
                        rise.pause();

                    } else {
                    }
                }
            });

            risereset.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (rise == null) {
                        Toast.makeText(getActivity(), "no file to stope", Toast.LENGTH_SHORT).show();
                    } else if (rise.isPlaying()) {
//                    int pos = rise.getCurrentPosition();
//                    rise.seekTo(pos);
                        rise.release();
                        rise = null;
                    }


                }
            });


        }




        return rootview;
    }

    private void releaseMediaPlayer() {
        // If the media player is not null, then it may be currently playing a sound.
        if (rise != null) {
            // Regardless of the current state of the media player, release its resources
            // because we no longer need it.
            rise.release();

            // Set the media player back to null. For our code, we've decided that
            // setting the media player to null is an easy way to tell that the media player
            // is not configured to play an audio file at the moment.
            rise = null;
        }
    }
}
