package com.example.android.miwok;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

/**
 * Created by Abdulrhman on 18/09/2016.
 */
public class pagerAdapter extends FragmentPagerAdapter {
    public pagerAdapter(FragmentManager fm) {
        super(fm);
    }


    @Override
    public Fragment getItem(int position) {
        Fragment fragment = null;
        if (position==0){
            fragment = new NumberFragment();
        }
     //   return fragment;
        return null;
    }

    @Override
    public int getCount() {
        return 5;
    }
}
