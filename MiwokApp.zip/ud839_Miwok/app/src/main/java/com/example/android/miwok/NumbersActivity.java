/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.android.miwok;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

public class NumbersActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_numbers);

        ArrayList<word> names = new ArrayList<word>();

        names.add(new word("one","lutti",R.mipmap.number_one));
        names.add(new word("two","otiiko",R.mipmap.number_two));
        names.add(new word("three","tolookosu",R.mipmap.number_three));
        names.add(new word("four","oyyisa",R.mipmap.number_four));
        names.add(new word("five","massokka",R.mipmap.number_five));
        names.add(new word("six","temmokka",R.mipmap.number_six));
        names.add(new word("seven","kenekaku",R.mipmap.number_seven));
        names.add(new word("eight","kawinta",R.mipmap.number_eight));
        names.add(new word("nine","wo’e",R.mipmap.number_nine));
        names.add(new word("ten","na’aacha",R.mipmap.number_ten));
        names.add(new word("one","lutti",R.mipmap.number_one));
        names.add(new word("two","otiiko",R.mipmap.number_two));
        names.add(new word("three","tolookosu",R.mipmap.number_three));
        names.add(new word("four","oyyisa",R.mipmap.number_four));
        names.add(new word("five","massokka",R.mipmap.number_five));
        names.add(new word("six","temmokka",R.mipmap.number_six));
        names.add(new word("seven","kenekaku",R.mipmap.number_seven));
        names.add(new word("eight","kawinta",R.mipmap.number_eight));
        names.add(new word("nine","wo’e",R.mipmap.number_nine));
        names.add(new word("ten","na’aacha",R.mipmap.number_ten));
        names.add(new word("one","lutti",R.mipmap.number_one));
        names.add(new word("two","otiiko",R.mipmap.number_two));
        names.add(new word("three","tolookosu",R.mipmap.number_three));
        names.add(new word("four","oyyisa",R.mipmap.number_four));
        names.add(new word("five","massokka",R.mipmap.number_five));
        names.add(new word("six","temmokka",R.mipmap.number_six));
        names.add(new word("seven","kenekaku",R.mipmap.number_seven));
        names.add(new word("eight","kawinta",R.mipmap.number_eight));
        names.add(new word("nine","wo’e",R.mipmap.number_nine));
        names.add(new word("ten","na’aacha",R.mipmap.number_ten));
        names.add(new word("one","lutti",R.mipmap.number_one));
        names.add(new word("two","otiiko",R.mipmap.number_two));
        names.add(new word("three","tolookosu",R.mipmap.number_three));
        names.add(new word("four","oyyisa",R.mipmap.number_four));
        names.add(new word("five","massokka",R.mipmap.number_five));
        names.add(new word("six","temmokka",R.mipmap.number_six));
        names.add(new word("seven","kenekaku",R.mipmap.number_seven));
        names.add(new word("eight","kawinta",R.mipmap.number_eight));
        names.add(new word("nine","wo’e",R.mipmap.number_nine));
        names.add(new word("ten","na’aacha",R.mipmap.number_ten));


      //  ArrayAdapter<word> itemsAdapter = new ArrayAdapter<word>(this, names);
        wordAdapter itemsAdapter = new wordAdapter(this, names,R.color.category_numbers);

        ListView listView = (ListView)findViewById(R.id.gridview);
        listView.setAdapter(itemsAdapter);

    }


        }





